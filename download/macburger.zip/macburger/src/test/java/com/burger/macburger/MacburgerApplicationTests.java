package com.burger.macburger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MacburgerApplicationTests {

	@Test
	void contextLoads() {
	}

}
